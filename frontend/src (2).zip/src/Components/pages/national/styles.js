// src/Components/pages/national/styles.js
import styled from 'styled-components';

export const PageContainer = styled.div`
  padding: 2rem;
  h1 {
    color: #2c3e50;
    font-size: 24px;
  }
`;
