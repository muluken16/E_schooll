// src/Components/pages/student/styles.js
import styled from 'styled-components';

export const PageContainer = styled.div`
  padding: 2rem;
  h1 {
    color: #457b9d;
  }
`;
